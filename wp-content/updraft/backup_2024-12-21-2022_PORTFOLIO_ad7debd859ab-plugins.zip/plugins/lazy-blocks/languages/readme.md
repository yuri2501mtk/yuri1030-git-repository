# Translation JS

Available filenames for translation:

* `lazy-blocks-en_US-lazyblocks-translation.json`

JSON content example:

      {
          "domain": "lazy-blocks",
          "locale_data": {
              "lazy-blocks": {
                  "": {
                      "domain": "lazy-blocks"
                  },
                  "Alongside Text": [
                      "Alongside Text Translated"
                  ],
                  "Checked": [
                      "Checked Translated"
                  ]
              }
          }
      }
